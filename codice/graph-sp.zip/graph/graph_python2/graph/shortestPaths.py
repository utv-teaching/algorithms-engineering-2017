from priorityQueue.PQbinaryHeap import PQbinaryHeap as PriorityQueue
from graph.base import Edge
from graph.GraphHelper import GraphHelper
from tree.treeArrayList import TreeArrayListNode as TreeNode
from tree.treeArrayList import TreeArrayList as Tree


INFINITE = float("inf")


def bellman_ford(graph, root):
    """
    Bellman-Ford's algorithm for the computation of the shortest path.
    The algorithm assumes a graph implemented as incidence list.
    ---
    Time Complexity: O(|V|*|E|)

    :param graph: the graph.
    :param root: the root node to start from.
    :return: the list of distances.
    """
    num_nodes = len(graph.nodes)

    # initialize distances
    dist = num_nodes * [INFINITE]
    dist[root] = 0

    # apply the relaxation step |V| times
    for i in range(num_nodes):
        for j in range(len(graph.inc)):
            curr = graph.inc[j].getFirstRecord()
            while curr is not None:
                edge = curr.elem
                tail = edge.tail
                head = edge.head
                weight = edge.weight
                # relaxation step
                if dist[tail] + weight < dist[head]:
                    dist[head] = dist[tail] + weight
                curr = curr.next

    return dist


def dijkstra(graph, root):
    """
    Dijkstra's algorithm for the computation of the shortest path.
    The algorithm assumes a graph implemented as incidence list.
    This implementation leverages the BinaryTree and PriorityQueue data
    structures.
    ---
    Time Complexity: O(|E|*log(|V|))
    Memory Complexity: O()

    :param graph: the graph.
    :param root: the root node to start from.
    :return: the shortest path.
    """
    num_nodes = len(graph.nodes)

    # initialize weights:
    # d[i] = inf for every i in E
    # d[i] = 0, if i == root
    current_weight = num_nodes * [INFINITE]
    current_weight[root] = 0

    # initialize the tree
    tree = Tree(TreeNode(root))
    tree_nodes = {root}
    tree_weight = 0

    # initialize the frontier (priority queue)
    pq = PriorityQueue()
    pq.insert((root, Edge(root, root, 0)), 0)

    # while the frontier is not empty ...
    while not pq.isEmpty():
        # pop from the priority queue the node u with the minimum distance
        pq_elem = pq.popMin()
        node = pq_elem[0]
        # if node not yet in the tree, update the tree
        if node not in tree_nodes:
            edge = pq_elem[1]
            tree_node = TreeNode(node)
            father = tree.foundNodeByElem(edge.tail)
            father.sons.append(tree_node)
            tree_node.father = father
            tree_nodes.add(node)
            tree_weight += edge.weight

        # for every edge (u,v) ...
        curr = graph.inc[node].getFirstRecord()
        while curr is not None:
            edge = curr.elem # the edge
            head = edge.head # the head node of the edge
            # if node v not yet added into the tree, push it into the priority
            # queue and apply the relaxation step
            if head not in tree_nodes:
                tail = edge.tail

                # weight of (u,v) (w(u,v))
                weight = edge.weight

                # current distance from root to tail (D(s,u))
                curr_dist_to_tail = current_weight[tail]

                pq.insert((head, edge), curr_dist_to_tail + weight)

                # relaxation step
                if current_weight[head] == INFINITE:
                    current_weight[head] = curr_dist_to_tail + weight
                elif curr_dist_to_tail + weight < current_weight[head]:
                    current_weight[head] = curr_dist_to_tail + weight

            curr = curr.next

    return current_weight


def floyd_warshall(graph):
    """
    Floyd-Warshall's algorithm for the computation of the shortest path.
    The algorithm assumes a graph implemented as incidence list.
    ---
    Time Complexity: O(|V|^3)

    :param graph: the graph.
    :return: the list of distances.
    """
    num_nodes = len(graph.nodes)

    # initialize distances:
    # dist[i,j]=inf, if (i,j) not in E
    # dist[i,i]=0,
    # dist[i,j]=w(i,j), if (i,j) in E
    dist = [[INFINITE] * num_nodes for i in range(num_nodes)]
    for i in range(num_nodes):
        dist[i][i] = 0
        curr = graph.inc[i].getFirstRecord()
        while curr is not None:
            edge = curr.elem
            dist[edge.tail][edge.head] = edge.weight
            curr = curr.next

    # apply the relaxation step |V| times on every edge
    for i in range(num_nodes):
        for x in range(num_nodes):
            for y in range(num_nodes):
                # relaxation step
                if dist[x][i] + dist[i][y] < dist[x][y]:
                    dist[x][y] = dist[x][i] + dist[i][y]

    return dist[0]


if __name__ == "__main__":
    graph = GraphHelper.buildGraph(5)

    graph.pprint()

    print "BellmanFord:"
    distances = bellman_ford(graph, 0)
    print "\tDistances:", distances

    print "Dijkstra:"
    distances = dijkstra(graph, 0)
    print "\tDistances:", distances

    print "FloydWarshall:"
    distances = floyd_warshall(graph)
    print "\tDistances:", distances
