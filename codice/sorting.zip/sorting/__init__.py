import sys

sys.setrecursionlimit(100000)

class printSwitch:
    dumpOperations = True
