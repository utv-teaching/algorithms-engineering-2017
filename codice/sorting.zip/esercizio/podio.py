"""In podio.py viene riportata una possibile soluzione all'esercizio
relativo alla gara dei cartoni animati."""

def riempiTempiGara(dizionarioGara, tempiGara, file):
    riga = file.readline()
    while riga != "":
        list = riga.split()
        nome = list[0]
        tempo = int(list[1])
        dizionarioGara[tempo] = nome
        tempiGara.append(tempo)
        riga = file.readline()

def stampaPodio(tempiGara, dizionarioGara):
    firstTime = tempiGara[0]
    secondTime = tempiGara[1]
    thirdTime = tempiGara[2]
    print("Il primo classificato e'", dizionarioGara[firstTime], "ed ha impiegato", str(firstTime), "secondi")
    print("Il secondo classificato e'", dizionarioGara[secondTime], "ed ha impiegato", str(secondTime), "secondi")
    print("Il terzo classificato e'", dizionarioGara[thirdTime], "ed ha impiegato", str(thirdTime), "secondi")

def selectionSort(l):
    """ It sorts the given Python list in ascending order.
        The key idea is that at the k-th step, you put the the right element in position k.
        O(n^2)
    """
    for k in range(len(l) - 1):
        minPos = k
        for j in range(k + 1, len(l)):
            if l[j] < l[minPos]:
                minPos = j
        l[minPos], l[k] = l[k], l[minPos]   #Assegnamento multiplo che permette di non usare variabili temporanee

def main():
    file = open("garaCartoniAnimati.txt", 'r')
    dizionarioGara = {}  #dizionario contenente nomi e tempi di gara
    tempiGara = []       #lista contenente i tempi di gara
    riempiTempiGara(dizionarioGara, tempiGara, file)
    selectionSort(tempiGara)
    #print(tempiGara)
    stampaPodio(tempiGara, dizionarioGara)

if __name__ == '__main__':
    main()
