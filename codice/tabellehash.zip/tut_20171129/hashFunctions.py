#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    File name: hashFunctions.py
    Author: Domenico Spera
    Date created: 11/10/2016
    Modified By: Laura Trivelloni
    Date last modified: 23/11/2017
    Python Version: 3.5.2

    Questo modulo implementa diverse funzioni di hashing.
"""

class HashFunction_module:
    """ Implementa un semplice modulo."""

    def hash(self, k, m):
        return k % m

class HashFunction_Adv:
    """ Implementa funzioni avanzate di hashing."""

    def numCifre(self, x):
        """Restituisce il numero di cifre in rappresentazione decimale"""
        c = 1
        while True:
            if x // (10**c) == 0: # == int(x / math.pow(10, c)) ma sconsigliato
                break
            c += 1
        return c

    def cif_k(self, k, i):
        """Restituisce la i-esima cifra di k"""
        c = self.numCifre(k)
        if i == 0:
            i += 1 #fix
        elif i < 0 or i > c:
            raise Exception("i is not in the range!")
        res = k % (10**i)           # <=> int(math.pow(10, i)) ma sconsigliato
        res = res // (10**(i - 1))  # <=> int(res / int(math.pow(10, i - 1))) ma sconsigliato
        return res

    def hash(self, k, m):
        mix = m
        numm = self.numCifre(m)
        numk = self.numCifre(k)
        for i in range(0, numk):
            cik = self.cif_k(k, i + 1)
            cimix = self.cif_k(m, i % numm + 1)
            #si rimpiazza la cifra i di mix con la somma modulo 10 delle \
            #due cifre calcolate sopra
            mix += ((cik + cimix) % 10) * (10**(i % numm)) \
                    - cimix * (10**(i % numm));
        return mix % m


class doubleHash:
    def hash(self, k, i, m):
        """ Combiniamo due funzioni hash diverse.

            h(k,i)=h1(k)+i*h2(k)  Se m e' primo e h2(k)>=1 e' coprimo rispetto
            ad m, si generano tutte le posizioni. Cio' e' garantito se h2(k)
            e' un intero fra 1 e m-1.
            Eliminato virtualmente il fenomeno dell'agglomerazione.
        """
        first = k % m
        second = k % (m - 1) + 1
        return (first + i * second) % m


class doubleHash_linearScan:
    """
        Scansione di elementi secondo la sequenza:
        c(k,i) = (h(k)+i) mod m.
        Può causare agglomerazione primaria.
    """
    def hash(self, k, i, m):
        return (k + i) % m


class doubleHash_quadraticScan:
    def hash(self, k, i, m):
        """
            Evita agglomerazione primaria, ma possibile
            agglomerazione secondaria.
            h(k,i)=(h(k)+c1*i+c2*i^2) mod m.
            Con c1 = c2 = 0.5 e m potenza di 2 è possibile
            scandire tutta la tabella.
            """
        return (int(k + 0.5 * i + 0.5 * i * i)) % m
