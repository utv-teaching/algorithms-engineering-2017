
"""
    File name: collisionsListHash.py
    Author: Domenico Spera
    Date created: 11/10/2016
    Modified By: Laura Trivelloni
    Date last modified: 23/11/2017
    Python Version: 3.5.2

    Questo modulo implementa una tabella hash con liste di collisione.

    Supporta le classiche operazioni di insert, search and delete key.
"""

import sys
import os

sys.path.append(str(os.environ.get("PYTHONPATH")) + "/Lez5/")

from dictionary.dictionaryUnorderedLinkedList import DictionaryUnorderedLinkedList
import hashFunctions


class DictCollisionListHash:

    def __init__(self, size, singleHashFunction):
        if type(size) is not int:
            raise ValueError
        self.lists = size * [None]
        self.size = size
        for i in range(size):
            self.lists[i] = DictionaryUnorderedLinkedList()
        self.hashFunction = singleHashFunction

    def insert(self, key, value):
        ind = self.hashFunction.hash(key, self.size)
        self.lists[ind].insert(key, value)

    def delete(self, key):
        ind = self.hashFunction.hash(key, self.size)
        self.lists[ind].delete(key)

    def search(self, key):
        ind = self.hashFunction.hash(key, self.size)
        return self.lists[ind].search(key)

    def stampa(self):
        for i in range(0, self.size):
            self.lists[i].theList.stampa()


if __name__ == "__main__":

    if len(sys.argv) != 3:
        print("Usage: program <size> <number_elements>")

    else:
        size = int(sys.argv[1])

        num = int(sys.argv[2])

        div = hashFunctions.HashFunction_module()

        rip = hashFunctions.HashFunction_Adv()

        print("\n\tMetodo divisione")
        """
            Con questo metodo la funzione hash è definita
            calcolando il resto della divisione della chiave k 
            per la size m della tabella, da cui dipende la qualità
            della funzione.
            In genere, m "buono" è un numero primo non vicino a una
            potenza di 2.
        """

        diz = DictCollisionListHash(size, div)
        for i in range(0, num):
            print("insert(" + str(i) + "," + str(2 * i) + ")")
            diz.insert(i, 2 * i)
        diz.stampa()

        print("\n\tMetodo ripiegamento")
        """
            Con questo metodo la chiave k è scomposta in l parti,
            e la funzione hash è funzione di l variabili con codominio
            in [0, m-1].
        """

        diz = DictCollisionListHash(size, rip)
        for i in range(0, num):
            print("insert(" + str(i) + "," + str(2 * i) + ")")
            diz.insert(i, 2 * i)
        diz.stampa()
