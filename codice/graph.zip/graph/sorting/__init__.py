import sys

sys.setrecursionlimit(100000)