"""
    File name: ClassesInheritanceExample.py
    Author: Laura Trivelloni
    Date created: 11/10/2017
    Python Version: 3.5.2

    This module implements an example of usage of inheritance and overriding method.
"""

class Person:

    def __init__(self, first, last, age):
        self.firstname = first
        self.lastname = last
        self.age = age

    def __str__(self):
        return "Name: " + self.firstname + " " + self.lastname + " - Age: " + str(self.age)

class Student(Person):

    def __init__(self, first, last, age, number):
        super().__init__(first, last, age)
        self.number = number

    # overwritten method
    def __str__(self):
        return super().__str__() + " - IDNumber: " +  self.number


def main() :

    x = Person("Jon", "Snow", 30)
    y = Student("Samwell", "Tarly", 28, "0123457")

    print(x)
    print(y)

if __name__ == "__main__" :
    main()