

def main():
    print("NON eseguito direttamente\n")


