import indirect


def mainDirect():
    print("Eseguito direttamente.\n")
    indirect.main()


if __name__ == "__main__":
    mainDirect()
