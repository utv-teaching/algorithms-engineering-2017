"""
    File name: stampaValori.py
    Author: Domenico Spera
    Date created: 11/10/2016
    Modified By: Laura Trivelloni
    Date last modified: 15/10/2017
    Python Version: 3.5.2

    This module implements functions to print the data read from file created by generatoreCasuale.py
    following the same order of the number sequence, .
"""
import sys
import os

sys.path.append(str(os.environ.get("PYTHONPATH")) + "/Lez2/")
# to import a library from a directory that isn't the current one
# it needs to specify the path
# $PYTHONPATH is the environment variable containing the project home
from linked_ds.queue.Queue import CodaListaCollegata

"""Questo file contiene tutte le funzioni che ci consetono di stampare i valori nell'ordine stabilito dalle tre diverse
varianti, che erano richieste dall'esercizio."""

import inputUtente
import sys
import os

sys.path.append(str(os.environ.get("PYTHONPATH")) + "/Lez2/")
# to import a library from a directory that isn't the current one
# it needs to specify the path
# $PYTHONPATH is the environment variable containing the project home
from linked_ds.stack.Stack import *


def ottieniValori(file):
    """Permette di ricavare una lista di valori interi partendo dalla stringa testo che contiene l'intero file. Da
    notare l'utilizzo del metodo split che semplifica il compito di estrazione dei numeri."""
    testo = file.read()
    list = testo.split()
    for i in range(len(list)):  # conversione degli elementi da stringhe ad interi
        list.append(int(list.pop(0)))
    print("La lista di numeri contenuti nel file sono:")
    print(list)
    return list


def apriFile():
    """Permette di chiedere all'utente il nome del file che si vuole aprire."""
    while True:
        # current directory path
        base_path = str(os.path.dirname(os.path.abspath(__file__)))

        nomeFile = base_path + "/" + inputUtente.inserisciNomeFile()
        try:
            return open(nomeFile + ".txt", 'r')
        except FileNotFoundError:
            print("File non trovato: inserire il percorso di un file esistente.")


def isDispari(num):
    """Permette di controllare se un numero è dispari."""
    if num % 2 == 0:
        return False
    return True


def stampaVariante1(list):
    """Permette di stampare i valori contenuti letti dal file seguendo la modalità della prima variante."""
    print("\n\nPRIMA VARIANTE:\n")
    queue = CodaListaCollegata()
    print("I numeri dispari sono:")
    for n in list:
        if isDispari(n):  # se il valore è dispari stampa direttamente in output
            print(n, end=" ")
        else:
            queue.enqueue(n)  # se il valore è pari inserisci il valore in una coda.
    print("\nI numeri pari sono:")
    while not (queue.isEmpty()):
        print(queue.dequeue(), end=" ")


def stampaVariante2(list):
    """Permette di stampare i valori contenuti letti dal file seguendo la modalità della seconda variante."""
    print("\n\nSECONDA VARIANTE:\n")
    stack = PilaListaCollegata()
    print("I numeri dispari sono:")
    for n in list:
        if isDispari(n):
            print(n, end=" ")  # se il valore è dispari stampa direttamente in output
        else:
            stack.push(n)  # se il valore è pari inserisci il valore in una pila
    print("\nI numeri pari sono:")
    while not (stack.isEmpty()):
        print(stack.pop(), end=" ")


def stampaVariante3(list):
    """Permette di stampare i valori contenuti letti dal file seguendo la modalità della terza variante."""
    print("\n\nTERZA VARIANTE:\n")
    stackPari = PilaListaCollegata()
    stackDispari = PilaListaCollegata()
    for n in list:
        if isDispari(n):
            stackDispari.push(n)  # se il valore è dispari inserisci il valore nella pila stackDispari
        else:
            stackPari.push(n)  # se il valore è pari inserisci il valore nella pila stackPari
    print("I numeri dispari sono:")
    while not (stackDispari.isEmpty()):
        print(stackDispari.pop(), end=" ")
    print("\nI numeri pari sono:")
    while not (stackPari.isEmpty()):
        print(stackPari.pop(), end=" ")


def main():
    file = apriFile()
    list = ottieniValori(file)
    file.close()
    stampaVariante1(list)
    stampaVariante2(list)
    stampaVariante3(list)


if __name__ == '__main__':
    main()
