"""
    File name: generatoreCasuale.py
    Author: Domenico Spera
    Date created: 11/10/2016
    Modified By: Laura Trivelloni
    Date last modified: 15/10/2017
    Python Version: 3.5.2

    This module implements an algorithm to create an output text file where N random numbers are written
    in a range from <min> to <max>, separated by a blank space.

"""

import random
import inputUtente
import os


def main():

    #current directory path
    base_path = str(os.path.dirname(os.path.abspath(__file__)))

    N = inputUtente.inserisciNumero()  # il numero degli elementi da scrivere sul file

    min = inputUtente.inserisciMinimo()  # il valore minimo che puo' assumere un elemento

    max = inputUtente.inserisciMassimo(min)  # il valore massimo che puo' assumere un elemento

    nomeFile = base_path + "/" + inputUtente.inserisciNomeFile()  # il nome del file di testo che si vuole creare

    file = open(nomeFile + ".txt", 'w')
    for i in range(N):
        file.write(str(random.randint(min, max)) + " ")
    file.close()


if __name__ == "__main__":
    main()
