"""
    File name: inputUtente.py
    Author: Domenico Spera
    Date created: 11/10/2016
    Modified By: Laura Trivelloni
    Date last modified: 15/10/2017
    Python Version: 3.5.2

    This module implements functions to receive user's input data.
"""


def check_int(s):
    """Permette di capire se una stringa puo effettivamente essere la rappresentazione di un intero"""
    if s[0] in ('-', '+'):
        return s[1:].isdigit()
    return s.isdigit()

def inserisciNumero():
    """Permette di inserire all'utente il numero N di elementi da inserire nel file"""
    while True:
        num = input("Inserisci il numero di elementi che vuoi inserire nel file:\n")
        if check_int(num):
            num = int(num)
            if num > 0:
                return num
            else:
                print("ATT: Il valore inserito deve essere maggiore di 0")
        else:
            print("ATT: il valore inserito deve essere un numero.")

def inserisciMinimo():
    """Permette di inserire all'utente il valore minimo che un elemento può assumere"""
    while True:
        num = input("Inserisci il valore minimo che un elemento puo' assumere:\n")
        if check_int(num):
            return int(num)
        else:
            print("L'elemento inserito deve essere un numero.")

def inserisciMassimo(min):
    """Permette di inserire all'utente il valore massimo che un elemento può assumere"""
    while True:
        num = input("Inserisci il valore minimo che un elemento puo' assumere:\n")
        if check_int(num):
            num = int(num)
            if num > min:
                return num
            else:
                print("ATT: Il valore massimo deve essere piu' grande del minimo!")
        else:
            print("Il valore inserito deve essere un numero!")

def inserisciNomeFile():
    """Permette di inserire all'utente il nome del file senza estensione txt"""
    while True:
        nomeFile = input("Inserisci il nome del file (senza estensione .txt):\n")
        if ".txt" in nomeFile:
            print("Non inserire l'estensione .txt")
        else:
            return nomeFile
